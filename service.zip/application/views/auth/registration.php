<div class="account-pages mt-5 mb-5">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-5">
                        <div class="card">
                            <!-- Logo-->
                            <div class="card-header pt-4 pb-4 text-center bg-primary">
                                <!-- <a href="index.html">
                                    <span><img src="assets/images/logo.png" alt="" height="18"></span>
                                </a> -->
                            </div>

                            <div class="card-body p-4">
                                
                                <div class="text-center w-75 m-auto">
                                    <h4 class="text-dark-50 text-center mt-0 font-weight-bold">Free Sign Up</h4>
                                    <p class="text-muted mb-4">Don't have an account? Create your account, it takes less than a minute </p>
                                </div>

                                <form action="<?= base_url('auth/registration'); ?>" method="post">

                                    <div class="form-group">
                                        <label for="fullname">Full Name</label>
                                        <input class="form-control" type="text" id="name" name="name" placeholder="e.g. Name" value="<?= set_value('name'); ?>">
                                    </div>
                                    <?= form_error('name', '<small class="text-danger">', '</small>'); ?>

                                    <div class="form-group">
                                        <label for="emailaddress">Email address</label>
                                        <input class="form-control" type="text" name="email" id="email" placeholder="e.g. email@gmail.com" value="<?= set_value('email'); ?>">
                                    </div>
                                    <?= form_error('email', '<small class="text-danger">', '</small>'); ?>

                                    <div class="form-group">
                                        <label for="emailaddress">Phone Number</label>
                                        <input class="form-control" type="number" name="phone" id="phone" placeholder="e.g. 081234567891" value="<?= set_value('phone'); ?>">
                                    </div>
                                    <?= form_error('phone', '<small class="text-danger">', '</small>'); ?>

                                    <div class="form-group">
                                        <label for="password">Password</label>
                                        <input class="form-control" type="password" name="password1" id="password1" placeholder="Enter your password">
                                    </div>
                                    <?= form_error('password1', '<small class="text-danger">', '</small>'); ?>

                                    <div class="form-group">
                                        <label for="password">Repeat Password</label>
                                        <input class="form-control" type="password" name="password2" id="password2" placeholder="Repeat your password">
                                    </div>

                                    <div class="form-group mb-0 text-center">
                                        <button class="btn btn-primary" type="submit"> Sign Up </button>
                                    </div>

                                </form>
                            </div> <!-- end card-body -->
                        </div>
                        <!-- end card -->

                        <div class="row mt-3">
                            <div class="col-12 text-center">
                                <p class="text-muted">Already have account? <a href="<?= base_url('auth'); ?>" class="text-dark ml-1"><b>Log In</b></a></p>
                            </div> <!-- end col-->
                        </div>
                        <!-- end row -->

                    </div> <!-- end col -->
                </div>
                <!-- end row -->
            </div>
            <!-- end container -->
        </div>
        <!-- end page -->